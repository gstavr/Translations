-------------------------- Custom Script ---------------------------
-------------------------- Add Custom Script Insert Scripts ---------------------------
-------------------------- Add Update Scripts ---------------------------
GO
PRINT('------------ Summary ------------')
GO
UPDATE st
SET st.TranslatedText = fd.TranslatedText
FROM X_StaticTranslations_FactoryDefaults fd
LEFT JOIN X_StaticTranslations st on fd.Cd = st.Cd and fd.[Language] = st.LanguageID
WHERE fd.TranslatedText <> st.TranslatedText and isnull(st.NoUpdate,0) = 0;
GO
	INSERT INTO X_StaticTranslations (Cd, LanguageID, Category, TranslatedText)
SELECT fd.Cd, fd.Language, fd.Category,fd.TranslatedText
FROM X_StaticTranslations_FactoryDefaults fd
LEFT JOIN X_StaticTranslations st on fd.Cd = st.Cd and fd.[Language] = st.LanguageID
WHERE st.Cd is null;
GO
UPDATE o
SET o.VALUE = fd.VALUE
FROM L_Object_FactoryDefaults fd
LEFT JOIN L_Object o on o.ID_TABLE =fd.ID_TABLE and o.ID_LANGUAGES = fd.ID_LANGUAGES and o.TABLE_NAME = fd.TABLE_NAME
WHERE o.VALUE <> fd.VALUE and isnull(o.NO_UPDATE,0) = 0;
GO
	INSERT INTO L_Object (ID_TABLE, ID_LANGUAGES, DATA_TYPE,VALUE,TABLE_NAME)
SELECT fd.ID_TABLE, fd.ID_LANGUAGES, fd.DATA_TYPE, fd.VALUE, fd.TABLE_NAME
FROM L_Object_FactoryDefaults fd
LEFT JOIN L_Object l on l.ID_TABLE = fd.ID_TABLE and l.ID_LANGUAGES = fd.ID_LANGUAGES and l.TABLE_NAME = fd.TABLE_NAME
WHERE l.ID_TABLE is null AND l.VALUE is null;
GO
PRINT 'Custom Script Completed'
